using System.Collections.Generic;

namespace OnlineMongoMigrationProcessor
{
    public class ChunkBoundaries
    {
        public List<Boundary> Boundaries { get; set; } = new();
    }
}